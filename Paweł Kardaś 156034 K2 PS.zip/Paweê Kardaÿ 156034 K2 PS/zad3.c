#include <stdio.h>
#include <stdlib.h>
int zadanie3(int **tab, int n, int m)
{
    int pom = 0;
    int wynik = 0;
    for(int i=0; i<n; i++)
    {
        for(int j=0; j<m; j++)
        {
            if(i%2==0 && j%2==0)
            {
                pom = *(*(tab+i)+j);
                wynik += pom*pom;
            }
        }
    }
    return wynik;
}
int main()
{
    int n = 3;
    int m = 4;
    int **tab = malloc(n*sizeof(float*));
    for(int i=0; i<n; i++)
    {
        *(tab+i) = malloc(m*sizeof(int));
    }
    *(*(tab+0)+0) = 2;
    *(*(tab+0)+1) = 3;
    *(*(tab+0)+2) = -2;
    *(*(tab+0)+3) = 8;
    *(*(tab+1)+0) = -1;
    *(*(tab+1)+1) = 8;
    *(*(tab+1)+2) = -4;
    *(*(tab+1)+3) = 3;
    *(*(tab+2)+0) = 3;
    *(*(tab+2)+1) = 5;
    *(*(tab+2)+2) = -2;
    *(*(tab+2)+3) = -9;
    printf("%d",zadanie3(tab,n,m));
    return 0;
}
