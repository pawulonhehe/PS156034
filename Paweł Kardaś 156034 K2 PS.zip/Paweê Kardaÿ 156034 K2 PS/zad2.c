#include <stdio.h>
#include <stdlib.h>

int zeze(char *nap)
{
    int i=0;
    while(nap[i]!=0)
    {
        i++;
    }
    return i;
}
void vix(char *nap)
{
    int pom = zeze(nap);
    for(int i=pom; i>0; i--)
    {
        if(nap[i]>='a' && nap[i] <='z')
        {
            nap[i] = '@';
        }
    }
    return nap;
}
int main()
{
    char n[] = "SwTwRwUwS";
    vix(n);
    printf("%s\n",n);
    return 0;
}
