#include <stdio.h>
#include <stdlib.h>

struct element {
    double x;
    struct element * next;
};

int zeze(struct element *lista1)
{
    int wynik = 0;
    struct element*wsk1 = lista1;
    while(wsk1!=NULL)
    {
        wynik+=wsk1->x;
        wsk1=wsk1->next;
    }
    return wynik;

};
int main()
{
    struct element *lista = malloc(sizeof(struct element));
    lista->x=3.456;
    lista->next = malloc(sizeof(struct element));
    lista ->next->x=4.5;
    lista->next->next = malloc(sizeof(struct element));
    lista->next->next->x=2.234;
    lista->next->next->next=NULL;
    printf("%d",zeze(lista));
    return 0;
}
