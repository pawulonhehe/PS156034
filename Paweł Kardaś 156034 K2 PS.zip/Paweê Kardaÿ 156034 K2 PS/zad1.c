#include <stdio.h>
#include <stdlib.h>

int main()
{
    int tab[3][5] = {{1,2,8,-2,2},{2,8,-1,3,-9},{3,4,1,2,11}};
    int a = sizeof(int**); //a= 4
    int * p = tab+1; //p= 0x61FEEC , *p = 2
    int r = *(*(tab+2)-1); // r= -9 , &r= 0x60fef4
    *p=*(tab+1)+3; //p= 0x61FEEC, **p = 3
    r= *(*(tab+2)+4); // r= 11 , &r= 0x60fef4
    return 0;
}
